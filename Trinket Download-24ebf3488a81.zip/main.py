# -*- coding: utf-8 -*-
import turtle as t
import random

# --- 깃허브 모듈 임포트 ---
# 깃허브에서 가져온 미니게임 파일들이 이 파일과 같은 폴더에 있어야 합니다.
import blackJack
import hangman
import numBaseball
import rsp

# 1. 초기 설정
t.shape("turtle")
t.penup()
t.speed(0)

# 전역 변수 초기화
current_stage = 1
is_loading = False        
is_interacting = False    
has_blackjack_ch4 = False

# 스테이지별 아이템 획득 여부 변수
has_desk_ch1 = has_bed_ch1 = has_closet_ch1 = has_drawer_ch1 = False
has_bed_ch2 = has_desk_ch2 = has_drawer_ch2 = has_game_ch2 = False
has_desk_ch3 = has_rope_ch3 = has_recorder_ch3 = has_paper_ch3 = False
has_file_ch4 = has_shovel_ch4 = has_cloth_ch4 = False

# 좌표 정의
COORD_DOOR = (0, 150)
COORD_A = (150, 150)    
COORD_B = (-150, -150)  
COORD_C = (150, -150)   
COORD_D = (-150, 150)      

screen = t.Screen()

def draw_map():
    global is_loading
    is_loading = True
    t.hideturtle()
    t.clear()
    t.penup()
    screen.bgcolor("#222222")
    
    # 맵 그리기 및 위치 표시
    t.goto(COORD_DOOR); t.dot(40, "red"); t.write(" [Door/Table]", align="center")
    t.goto(COORD_A); t.dot(40, "#8B4513"); t.write(" [A]", align="center")
    t.goto(COORD_B); t.dot(40, "#4682B4"); t.write(" [B]", align="center")
    t.goto(COORD_C); t.dot(40, "#8A2BE2"); t.write(" [C]", align="center")
    t.goto(COORD_D); t.dot(40, "#2E8B57"); t.write(" [D]", align="center")
    
    t.goto(0, 0)
    t.showturtle()
    
    # 각 스테이지 시작 문구
    print("\n--- STAGE {0} START ---".format(current_stage))
    if current_stage == 1:
        print("녹색이 서랍, 갈색이 책상, 보라색이 옷장, 파란색이 침대인 것 같다.")
    elif current_stage == 2:
        print("녹색이 게임, 갈색이 책상, 보라색이 서랍, 파란색이 침대인 것 같다.")
    elif current_stage == 3:
        print("녹색이 종이, 갈색이 책상, 보라색이 녹음기, 파란색이 밧줄인 것 같다.")
    elif current_stage == 4:
        print("녹색이 신분증, 갈색이 파일, 보라색이 천, 파란색이 삽인 것 같다.")
    is_loading = False

def disable_keys():
    screen.onkey(None, "w"); screen.onkey(None, "s")
    screen.onkey(None, "a"); screen.onkey(None, "d")

def enable_keys():
    screen.onkey(up, "w"); screen.onkey(down, "s")
    screen.onkey(left, "a"); screen.onkey(right, "d")
    screen.listen()

def check_interaction():
    global is_interacting, current_stage, has_blackjack_ch4
    global has_desk_ch1, has_bed_ch1, has_closet_ch1, has_drawer_ch1
    global has_bed_ch2, has_desk_ch2, has_drawer_ch2, has_game_ch2
    global has_desk_ch3, has_rope_ch3, has_recorder_ch3, has_paper_ch3
    global has_file_ch4, has_shovel_ch4, has_cloth_ch4
    
    if is_loading or is_interacting: return
    is_interacting = True
    
    try:
        # 문/테이블 상호작용 및 최종 엔딩 분기
        if t.distance(COORD_DOOR) < 40:
            t.backward(40)
            disable_keys()
            # 블랙잭 승리 후 4스테이지에서 문 조사 시 최종 엔딩 로직
            if current_stage == 4 and has_blackjack_ch4:
                print("\n[문을 다시 조사하면 최종 선택지가 등장함.]")
                print("1. 진실을 받아들인다.")
                print("2. 기억을 지우고 처음으로 돌아간다.")
                print("3. 끝까지 그를 사기꾼이라고 주장한다.")
                choice = input("선택: ")
                if choice == "1":
                    print("주인공은 피해자가 사기꾼이 아니라 암행 경찰이었다는 사실과, 자신이 그를 납치하고 죽게 만들었다는 사실을 인정함.")
                    print("시스템 문구: 피해자가 진실을 인식했습니다. 현실의 감옥에서 깨어나며 정상 엔딩.")
                elif choice == "2":
                    print("주인공은 진실을 거부하고 기억 삭제를 선택함.")
                    print("시스템 문구: 기억 초기화를 시작합니다. 다시 1점의 방에서 깨어나는 반복 엔딩.")
                elif choice == "3":
                    print("주인공은 끝까지 피해자를 사기꾼이라고 주장함.")
                    print("시스템 문구: 피해자가 현실 인식을 거부했습니다. 교화 단계를 강화합니다. 더 깊은 기억 복구 단계로 넘어가는 배드 엔딩.")
            
            # 블랙잭 미니게임 실행
            elif current_stage == 4:
                print("카드 테이블에 다가갔다. 마지막 판을 시작합니다. 이번에는 진실을 확인하기 위한 판입니다.")
                if blackJack.play():
                    print("블랙잭 승리! 기억의 파편이 공개된다.")
                    has_blackjack_ch4 = True
                else:
                    print("패배했다. 다시 도전하세요.")
            
            # 스테이지별 비밀번호 체크
            else:
                target_pwd = None
                if current_stage == 1 and has_desk_ch1 and has_bed_ch1 and has_closet_ch1 and has_drawer_ch1: target_pwd = "7294"
                elif current_stage == 2 and has_desk_ch2 and has_bed_ch2 and has_drawer_ch2 and has_game_ch2: target_pwd = "312"
                elif current_stage == 3 and has_desk_ch3 and has_rope_ch3 and has_recorder_ch3 and has_paper_ch3: target_pwd = "납치"
                
                if target_pwd:
                    pwd = input("Password: ")
                    if pwd == target_pwd:
                        print("Success!")
                        current_stage += 1
                        draw_map()
                    else:
                        print("비밀번호가 다릅니다.")
                else:
                    print("단서가 더 필요할 것 같다.")
            enable_keys()
        
        # 1 스테이지 아이템 획득
        elif current_stage == 1:
            if t.distance(COORD_A) < 40 and not has_desk_ch1: t.backward(40); has_desk_ch1 = True; print("7일 안에 갚을 것...7")
            elif t.distance(COORD_B) < 40 and not has_bed_ch1: t.backward(40); has_bed_ch1 = True; print("침대 밑에 메모가 있다. 2번째 기회...2")
            elif t.distance(COORD_C) < 40 and not has_closet_ch1: t.backward(40); has_closet_ch1 = True; print("옷장 안엔 찢어진 복권이 있었다. 90000+0...9")
            elif t.distance(COORD_D) < 40 and not has_drawer_ch1: t.backward(40); has_drawer_ch1 = True; print("서랍 안엔 찢어진 복권이 있었다. 00004+0...4")
        
        # 2 스테이지 아이템 및 미니게임
        elif current_stage == 2:
            if t.distance(COORD_A) < 40 and not has_desk_ch2: t.backward(40); has_desk_ch2 = True; print("낡은 카드와 겜블 칩이 있다.")
            elif t.distance(COORD_B) < 40 and not has_bed_ch2: t.backward(40); has_bed_ch2 = True; print("찢어진 복권이 있다.")
            elif t.distance(COORD_C) < 40 and not has_drawer_ch2: t.backward(40); has_drawer_ch2 = True; print("사기꾼이라고 적힌 메모가 있다.")
            elif t.distance(COORD_D) < 40 and not has_game_ch2:
                t.backward(40); disable_keys()
                print("작은 게임기 화면에 글자가 떠 있다. '이기면 그날의 판을 보여주겠다.'")
                if rsp.play():
                    print("승리! 순서: 복권 > 카드 > 사기꾼"); has_game_ch2 = True
                elif hangman.play():
                    print("승리! 순서: 복권 > 카드 > 사기꾼"); has_game_ch2 = True
                enable_keys()
        
        # 3 스테이지 아이템 및 미니게임
        elif current_stage == 3:
            if t.distance(COORD_A) < 40 and not has_desk_ch3: t.backward(40); has_desk_ch3 = True; print("피해자를 사기꾼이라 써놓은 나의 메모다.")
            elif t.distance(COORD_B) < 40 and not has_rope_ch3: t.backward(40); has_rope_ch3 = True; print("누군가를 묶었던 듯한 밧줄이다.")
            elif t.distance(COORD_C) < 40 and not has_recorder_ch3: t.backward(40); has_recorder_ch3 = True; print("녹음기 너머로 피해자의 음성이 흘러 나온다.")
            elif t.distance(COORD_D) < 40 and not has_paper_ch3:
                t.backward(40); disable_keys()
                if numBaseball.play():
                    print("정답! 단서 '납치' 획득"); has_paper_ch3 = True
                enable_keys()
        
        # 4 스테이지 아이템 획득
        elif current_stage == 4:
            if t.distance(COORD_A) < 40 and not has_file_ch4: t.backward(40); has_file_ch4 = True; print("파일 획득: 사건 장소, 납치, 감금 내용이 나와 있다.")
            elif t.distance(COORD_B) < 40 and not has_shovel_ch4: t.backward(40); has_shovel_ch4 = True; print("삽 획득: 삽 끝에 흙이 묻어 있다.")
            elif t.distance(COORD_C) < 40 and not has_cloth_ch4: t.backward(40); has_cloth_ch4 = True; print("천 획득: 낡은 천에 핏자국이 있다.")
            elif t.distance(COORD_D) < 40: print("신분증 획득: 피해자는 암행 경찰이었다.")
    finally:
        is_interacting = False

def up(): t.sety(t.ycor() + 20); check_interaction()
def down(): t.sety(t.ycor() - 20); check_interaction()
def left(): t.setx(t.xcor() - 20); check_interaction()
def right(): t.setx(t.xcor() + 20); check_interaction()

screen.listen()
enable_keys()
draw_map()
t.mainloop()
